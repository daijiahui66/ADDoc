from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
import uvicorn
from database import engine, Base, SessionLocal
from routers import auth, upload, structure, docs, search, stats, users, backup, activity
from init_db import init_db
import os

app = FastAPI()

origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:5174",
    "http://127.0.0.1:5174",
    "http://localhost:5175",
    "http://127.0.0.1:5175",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure uploads directory exists
os.makedirs("uploads", exist_ok=True)
# Ensure data directory exists for SQLite
os.makedirs("data", exist_ok=True)

# Mount static files
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Include routers
app.include_router(auth.router, prefix="/api")
app.include_router(upload.router, prefix="/api")
app.include_router(structure.router, prefix="/api")
app.include_router(docs.router, prefix="/api")
app.include_router(search.router, prefix="/api")
app.include_router(stats.router, prefix="/api")
app.include_router(users.router, prefix="/api")
app.include_router(backup.router, prefix="/api")
app.include_router(activity.router, prefix="/api/activity", tags=["Activity"])

# Check if dist directory exists for static files (Production/Docker)
if os.path.exists("dist"):
    print("Mounting static files from dist directory...")
    # Mount assets
    app.mount("/assets", StaticFiles(directory="dist/assets"), name="assets")
    # Mount root to dist with html=True to serve index.html
    app.mount("/", StaticFiles(directory="dist", html=True), name="static")

@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    init_db(db)
    db.close()

@app.get("/api/health")
def read_health():
    return {"status": "ok", "backend": "FastAPI running with uv"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
